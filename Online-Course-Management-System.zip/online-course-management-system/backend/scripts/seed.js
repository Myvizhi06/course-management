// Usage:
//   npm run seed         -> inserts sample courses (skips any that already exist)
//   npm run seed:clear   -> removes ONLY the sample courses below (and only if they have no enrollments)
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const mongoose = require('mongoose');
const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');

const sampleCourses = [
  {
    title: 'Full-Stack Web Development with React and Node.js',
    description: 'Build modern web applications from scratch. You will learn HTML, CSS, JavaScript, React, Express, and MongoDB while building three portfolio projects.',
    instructor: 'Dr. Ananya Sharma',
    category: 'Web Development',
    level: 'Intermediate',
    durationWeeks: 12,
    price: 4999,
    prerequisites: 'Basic JavaScript knowledge and familiarity with HTML.',
    learningOutcomes: ['Build responsive React user interfaces', 'Design REST APIs with Express', 'Model data with MongoDB and Mongoose', 'Deploy a full-stack application'],
  },
  {
    title: 'Data Science with Python',
    description: 'Learn data analysis, visualization, and statistical thinking using Python, Pandas, NumPy, and Matplotlib through real-world datasets.',
    instructor: 'Prof. Rahul Mehta',
    category: 'Data Science',
    level: 'Beginner',
    durationWeeks: 10,
    price: 3999,
    prerequisites: 'No prior programming experience required.',
    learningOutcomes: ['Clean and analyze data with Pandas', 'Create meaningful visualizations', 'Apply basic statistics to real problems', 'Present insights from data'],
  },
  {
    title: 'Machine Learning and Artificial Intelligence Fundamentals',
    description: 'Understand how machine learning models work and train your own using scikit-learn. Covers regression, classification, clustering, and an introduction to neural networks.',
    instructor: 'Dr. Priya Nair',
    category: 'Artificial Intelligence',
    level: 'Advanced',
    durationWeeks: 14,
    price: 6499,
    prerequisites: 'Python programming, linear algebra, and basic statistics.',
    learningOutcomes: ['Train and evaluate ML models', 'Understand overfitting and model selection', 'Build a simple neural network', 'Apply AI responsibly'],
  },
  {
    title: 'UI/UX Design Essentials',
    description: 'Master the design process from user research to high-fidelity prototypes. Practice wireframing, usability testing, and design systems.',
    instructor: 'Meera Iyer',
    category: 'UI/UX Design',
    level: 'Beginner',
    durationWeeks: 8,
    price: 2999,
    prerequisites: 'None. Curiosity about how people use products.',
    learningOutcomes: ['Conduct user research', 'Create wireframes and prototypes', 'Apply accessibility principles', 'Build a design portfolio piece'],
  },
  {
    title: 'Cybersecurity Fundamentals and Ethical Hacking',
    description: 'Learn how attackers think and how to defend systems. Topics include network security, web vulnerabilities, cryptography basics, and incident response.',
    instructor: 'Arjun Verma',
    category: 'Cybersecurity',
    level: 'Intermediate',
    durationWeeks: 10,
    price: 5499,
    prerequisites: 'Basic networking and Linux command line knowledge.',
    learningOutcomes: ['Identify common web vulnerabilities', 'Perform basic network reconnaissance legally', 'Apply defensive security controls', 'Write a security assessment report'],
  },
  {
    title: 'Cloud Computing with AWS',
    description: 'Get hands-on with core cloud services: compute, storage, networking, and databases. Prepare for an entry-level cloud certification.',
    instructor: 'Kavita Reddy',
    category: 'Cloud Computing',
    level: 'Beginner',
    durationWeeks: 9,
    price: 4499,
    prerequisites: 'Basic understanding of operating systems and networks.',
    learningOutcomes: ['Launch and manage virtual servers', 'Store and serve data in the cloud', 'Design a simple scalable architecture', 'Understand cloud cost management'],
  },
];

const run = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/onlineCourseDB';
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
  const clear = process.argv.includes('--clear');

  if (clear) {
    let removed = 0;
    let skipped = 0;
    for (const sample of sampleCourses) {
      const course = await Course.findOne({ title: sample.title, instructor: sample.instructor });
      if (!course) continue;
      if (await Enrollment.exists({ course: course._id })) {
        skipped += 1;
        console.log(`Skipped "${course.title}" (has enrollments)`);
        continue;
      }
      await course.deleteOne();
      removed += 1;
    }
    console.log(`Removed ${removed} sample course(s). Skipped ${skipped}.`);
  } else {
    let inserted = 0;
    for (const sample of sampleCourses) {
      const exists = await Course.exists({ title: sample.title, instructor: sample.instructor });
      if (exists) continue;
      await Course.create(sample);
      inserted += 1;
    }
    console.log(`Inserted ${inserted} new course(s); ${sampleCourses.length - inserted} already existed.`);
  }
};

run()
  .catch((err) => {
    console.error('Seed failed:', err.message);
    process.exitCode = 1;
  })
  .finally(() => mongoose.disconnect());
