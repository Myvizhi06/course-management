const mongoose = require('mongoose');

// Wraps async route handlers so rejected promises reach the error middleware.
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

class ApiError extends Error {
  constructor(statusCode, message, errors) {
    super(message);
    this.statusCode = statusCode;
    this.errors = errors;
  }
}

// Strict check: exactly 24 hex characters.
const isObjectId = (value) => typeof value === 'string' && /^[a-f\d]{24}$/i.test(value);

// Rejects invalid MongoDB ObjectIds before they reach the database.
const validateObjectId = (paramName = 'id') => (req, res, next) => {
  if (!isObjectId(req.params[paramName])) {
    return next(new ApiError(400, 'Invalid ID format'));
  }
  next();
};

// Returns 503 when the database is not connected.
const requireDb = (req, res, next) => {
  if (mongoose.connection.readyState !== 1) {
    return next(new ApiError(503, 'Database is not connected. Please try again later.'));
  }
  next();
};

const notFound = (req, res, next) => {
  next(new ApiError(404, `Route not found: ${req.method} ${req.originalUrl}`));
};

const errorHandler = (err, req, res, next) => { // eslint-disable-line no-unused-vars
  let status = err.statusCode || 500;
  let message = err.message || 'Server error';
  let errors = err.errors;

  if (err instanceof mongoose.Error.ValidationError) {
    status = 400;
    message = 'Validation failed';
    errors = Object.values(err.errors).map((e) => e.message);
  } else if (err instanceof mongoose.Error.CastError) {
    status = 400;
    message = `Invalid value for ${err.path}`;
  } else if (err.code === 11000) {
    status = 409;
    message = 'This student is already enrolled in the selected course';
  } else if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Invalid JSON in request body';
  } else if (err.type === 'entity.too.large') {
    status = 413;
    message = 'Request body is too large';
  } else if (err.name === 'MongooseServerSelectionError' || err.name === 'MongoNetworkError') {
    status = 503;
    message = 'Database is unavailable';
  }

  if (status >= 500) {
    // Expected errors (ApiError, e.g. database offline) only log a short line; unexpected ones log the stack.
    if (err instanceof ApiError) console.warn(`[${status}] ${message}`);
    else console.error(err);
    if (process.env.NODE_ENV === 'production' && !(err instanceof ApiError)) message = 'Internal server error';
  }

  res.status(status).json({
    success: false,
    message,
    errors: Array.isArray(errors) ? errors : undefined,
  });
};

module.exports = { asyncHandler, ApiError, isObjectId, validateObjectId, requireDb, notFound, errorHandler };
