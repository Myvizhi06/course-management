const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const courseRoutes = require('./routes/courseRoutes');
const enrollmentRoutes = require('./routes/enrollmentRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const { ApiError, requireDb, notFound, errorHandler } = require('./middleware/errorMiddleware');

const app = express();

const allowedOrigins = (process.env.CORS_ORIGIN || 'http://localhost:5173,http://127.0.0.1:5173')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow tools without an Origin header (curl, Postman) and the configured frontend origins.
      if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new ApiError(403, 'This origin is not allowed by CORS. Add it to CORS_ORIGIN in backend/.env.'));
    },
  })
);
app.use(express.json({ limit: '100kb' }));

// Health check: reports API and database state only (no configuration details).
app.get('/api/health', (req, res) => {
  const states = { 0: 'disconnected', 1: 'connected', 2: 'connecting', 3: 'disconnecting' };
  const dbState = states[mongoose.connection.readyState] || 'unknown';
  res.status(dbState === 'connected' ? 200 : 503).json({
    success: dbState === 'connected',
    message: dbState === 'connected' ? 'API is running' : 'API is running but the database is not connected',
    data: { api: 'ok', database: dbState, timestamp: new Date().toISOString() },
  });
});

app.use('/api/courses', requireDb, courseRoutes);
app.use('/api/enrollments', requireDb, enrollmentRoutes);
app.use('/api/dashboard', requireDb, dashboardRoutes);

app.use(notFound);
app.use(errorHandler);

module.exports = app;
