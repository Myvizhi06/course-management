const express = require('express');
const {
  getEnrollments,
  getEnrollmentById,
  createEnrollment,
  updateEnrollment,
  deleteEnrollment,
} = require('../controllers/enrollmentController');
const { validateObjectId } = require('../middleware/errorMiddleware');

const router = express.Router();

router.route('/').get(getEnrollments).post(createEnrollment);
router
  .route('/:id')
  .get(validateObjectId(), getEnrollmentById)
  .put(validateObjectId(), updateEnrollment)
  .delete(validateObjectId(), deleteEnrollment);

module.exports = router;
