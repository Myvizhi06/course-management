const express = require('express');
const { getCourses, getCourseById, createCourse, updateCourse, deleteCourse } = require('../controllers/courseController');
const { validateObjectId } = require('../middleware/errorMiddleware');

const router = express.Router();

router.route('/').get(getCourses).post(createCourse);
router.route('/:id').get(validateObjectId(), getCourseById).put(validateObjectId(), updateCourse).delete(validateObjectId(), deleteCourse);

module.exports = router;
