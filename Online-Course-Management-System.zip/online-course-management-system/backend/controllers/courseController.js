const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');
const { asyncHandler, ApiError } = require('../middleware/errorMiddleware');

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Only these fields can be set by clients (prevents unexpected fields being saved).
const pickCourseFields = (body) => {
  const fields = {};
  ['title', 'description', 'instructor', 'category', 'level', 'durationWeeks', 'price', 'imageUrl', 'prerequisites'].forEach((key) => {
    if (body[key] !== undefined) fields[key] = body[key];
  });

  if (body.learningOutcomes !== undefined) {
    const raw = Array.isArray(body.learningOutcomes) ? body.learningOutcomes : String(body.learningOutcomes).split('\n');
    fields.learningOutcomes = raw.map((item) => String(item).trim()).filter(Boolean);
  }

  // Numbers may arrive as strings from forms; convert them and reject blanks / non-numbers clearly.
  const numberLabels = { price: 'Price', durationWeeks: 'Duration' };
  Object.entries(numberLabels).forEach(([key, label]) => {
    if (fields[key] === undefined) return;
    const raw = fields[key];
    const value = typeof raw === 'string' && raw.trim() === '' ? NaN : Number(raw);
    if (raw === null || Number.isNaN(value)) {
      throw new ApiError(400, 'Validation failed', [`${label} must be a valid number`]);
    }
    fields[key] = value;
  });
  return fields;
};

// GET /api/courses?search=&category=&level=
const getCourses = asyncHandler(async (req, res) => {
  const { search, category, level } = req.query;
  const filter = {};

  if (typeof search === 'string' && search.trim()) {
    const regex = new RegExp(escapeRegex(search.trim()), 'i');
    filter.$or = [{ title: regex }, { instructor: regex }, { description: regex }, { category: regex }];
  }
  if (typeof category === 'string' && category.trim()) filter.category = category.trim();
  if (typeof level === 'string' && level.trim()) filter.level = level.trim();

  const courses = await Course.find(filter).sort({ createdAt: -1 });

  // Attach the number of enrollments per course (useful for the admin table).
  const counts = await Enrollment.aggregate([{ $group: { _id: '$course', count: { $sum: 1 } } }]);
  const countMap = new Map(counts.map((c) => [String(c._id), c.count]));
  const data = courses.map((c) => ({ ...c.toObject(), enrollmentCount: countMap.get(String(c._id)) || 0 }));

  res.json({ success: true, message: 'Courses retrieved successfully', count: data.length, data });
});

// GET /api/courses/:id
const getCourseById = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);
  if (!course) throw new ApiError(404, 'Course not found');
  const enrollmentCount = await Enrollment.countDocuments({ course: course._id });
  res.json({ success: true, message: 'Course retrieved successfully', data: { ...course.toObject(), enrollmentCount } });
});

// POST /api/courses
const createCourse = asyncHandler(async (req, res) => {
  const course = await Course.create(pickCourseFields(req.body));
  res.status(201).json({ success: true, message: 'Course created successfully', data: course });
});

// PUT /api/courses/:id
const updateCourse = asyncHandler(async (req, res) => {
  const course = await Course.findByIdAndUpdate(req.params.id, pickCourseFields(req.body), {
    new: true,
    runValidators: true,
  });
  if (!course) throw new ApiError(404, 'Course not found');
  res.json({ success: true, message: 'Course updated successfully', data: course });
});

// DELETE /api/courses/:id
// Rule: a course that still has enrollments cannot be deleted (keeps enrollment records valid).
const deleteCourse = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id);
  if (!course) throw new ApiError(404, 'Course not found');

  const enrollmentCount = await Enrollment.countDocuments({ course: course._id });
  if (enrollmentCount > 0) {
    throw new ApiError(
      409,
      `Cannot delete this course because it has ${enrollmentCount} enrollment(s). Delete or move those enrollments first.`
    );
  }

  await course.deleteOne();
  res.json({ success: true, message: 'Course deleted successfully', data: { _id: course._id } });
});

module.exports = { getCourses, getCourseById, createCourse, updateCourse, deleteCourse };
