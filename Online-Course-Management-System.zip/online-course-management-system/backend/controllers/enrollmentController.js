const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');
const { asyncHandler, ApiError, isObjectId } = require('../middleware/errorMiddleware');

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const COURSE_FIELDS = 'title instructor category level durationWeeks price imageUrl';

const pickEnrollmentFields = (body) => {
  const fields = {};
  ['studentName', 'email', 'phone', 'course', 'status', 'enrollmentDate'].forEach((key) => {
    if (body[key] !== undefined && body[key] !== '') fields[key] = body[key];
  });
  if (fields.course !== undefined && !isObjectId(fields.course)) {
    throw new ApiError(400, 'Validation failed', ['Invalid course ID']);
  }
  return fields;
};

// Call after schema validation, so courseId is already a well-formed ObjectId.
const assertCourseExists = async (courseId) => {
  const exists = await Course.exists({ _id: courseId });
  if (!exists) throw new ApiError(404, 'Selected course does not exist');
};

// GET /api/enrollments?search=&status=&courseId=
const getEnrollments = asyncHandler(async (req, res) => {
  const { search, status, courseId } = req.query;
  const filter = {};

  if (typeof status === 'string' && status.trim()) filter.status = status.trim();
  if (typeof courseId === 'string' && courseId.trim()) {
    if (!isObjectId(courseId)) throw new ApiError(400, 'Invalid course ID');
    filter.course = courseId;
  }
  if (typeof search === 'string' && search.trim()) {
    const regex = new RegExp(escapeRegex(search.trim()), 'i');
    const matchingCourses = await Course.find({ title: regex }).select('_id');
    filter.$or = [
      { studentName: regex },
      { email: regex },
      { phone: regex },
      { course: { $in: matchingCourses.map((c) => c._id) } },
    ];
  }

  const enrollments = await Enrollment.find(filter).populate('course', COURSE_FIELDS).sort({ createdAt: -1 });
  res.json({ success: true, message: 'Enrollments retrieved successfully', count: enrollments.length, data: enrollments });
});

// GET /api/enrollments/:id
const getEnrollmentById = asyncHandler(async (req, res) => {
  const enrollment = await Enrollment.findById(req.params.id).populate('course', COURSE_FIELDS);
  if (!enrollment) throw new ApiError(404, 'Enrollment not found');
  res.json({ success: true, message: 'Enrollment retrieved successfully', data: enrollment });
});

// POST /api/enrollments
const createEnrollment = asyncHandler(async (req, res) => {
  // Validate every field first so the user sees all problems at once.
  const enrollment = new Enrollment(pickEnrollmentFields(req.body));
  await enrollment.validate();
  await assertCourseExists(enrollment.course);

  // Friendly duplicate check; the unique index is the final safeguard against race conditions.
  if (await Enrollment.exists({ email: enrollment.email, course: enrollment.course })) {
    throw new ApiError(409, 'This student is already enrolled in the selected course');
  }

  await enrollment.save();
  await enrollment.populate('course', COURSE_FIELDS);
  res.status(201).json({ success: true, message: 'Enrollment created successfully', data: enrollment });
});

// PUT /api/enrollments/:id
const updateEnrollment = asyncHandler(async (req, res) => {
  const fields = pickEnrollmentFields(req.body);
  const enrollment = await Enrollment.findById(req.params.id);
  if (!enrollment) throw new ApiError(404, 'Enrollment not found');

  // Assign and save (instead of findByIdAndUpdate) so email lowercasing and all validators run.
  enrollment.set(fields);
  await enrollment.validate();
  if (fields.course) await assertCourseExists(enrollment.course);
  await enrollment.save();
  await enrollment.populate('course', COURSE_FIELDS);
  res.json({ success: true, message: 'Enrollment updated successfully', data: enrollment });
});

// DELETE /api/enrollments/:id
const deleteEnrollment = asyncHandler(async (req, res) => {
  const enrollment = await Enrollment.findByIdAndDelete(req.params.id);
  if (!enrollment) throw new ApiError(404, 'Enrollment not found');
  res.json({ success: true, message: 'Enrollment deleted successfully', data: { _id: enrollment._id } });
});

module.exports = { getEnrollments, getEnrollmentById, createEnrollment, updateEnrollment, deleteEnrollment };
