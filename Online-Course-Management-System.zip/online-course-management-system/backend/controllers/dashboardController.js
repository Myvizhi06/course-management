const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');
const { asyncHandler } = require('../middleware/errorMiddleware');

// GET /api/dashboard/stats  - every number comes from the database
const getStats = asyncHandler(async (req, res) => {
  const [totalCourses, totalEnrollments, categories, instructors, statusBreakdown] = await Promise.all([
    Course.countDocuments(),
    Enrollment.countDocuments(),
    Course.aggregate([{ $group: { _id: '$category', count: { $sum: 1 } } }, { $sort: { count: -1, _id: 1 } }]),
    Course.distinct('instructor'),
    Enrollment.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
  ]);

  res.json({
    success: true,
    message: 'Dashboard statistics retrieved successfully',
    data: {
      totalCourses,
      totalEnrollments,
      totalInstructors: instructors.length,
      totalCategories: categories.length,
      categories: categories.map((c) => ({ name: c._id, count: c.count })),
      enrollmentsByStatus: statusBreakdown.map((s) => ({ status: s._id, count: s.count })),
    },
  });
});

module.exports = { getStats };
