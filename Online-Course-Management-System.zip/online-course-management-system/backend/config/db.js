const mongoose = require('mongoose');

const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/onlineCourseDB';
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log(`MongoDB connected: database "${mongoose.connection.name}"`);
  } catch (error) {
    console.error('MongoDB connection failed:', error.message);
    console.error('Make sure the MongoDB service is running and MONGODB_URI in backend/.env is correct.');
    throw error;
  }
};

module.exports = connectDB;
