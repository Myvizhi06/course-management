const mongoose = require('mongoose');

const LEVELS = ['Beginner', 'Intermediate', 'Advanced'];

const courseSchema = new mongoose.Schema(
  {
    title: { type: String, required: [true, 'Course title is required'], trim: true, maxlength: 150 },
    description: { type: String, required: [true, 'Course description is required'], trim: true, maxlength: 5000 },
    instructor: { type: String, required: [true, 'Instructor name is required'], trim: true, maxlength: 100 },
    category: { type: String, required: [true, 'Category is required'], trim: true, maxlength: 60 },
    level: {
      type: String,
      enum: { values: LEVELS, message: 'Level must be Beginner, Intermediate, or Advanced' },
      default: 'Beginner',
    },
    // Duration is stored in weeks (a positive number) so it is consistent and easy to validate.
    durationWeeks: {
      type: Number,
      required: [true, 'Duration is required'],
      min: [1, 'Duration must be at least 1 week'],
      max: [520, 'Duration is too large'],
    },
    price: { type: Number, required: [true, 'Price is required'], min: [0, 'Price cannot be negative'] },
    imageUrl: {
      type: String,
      trim: true,
      default: '',
      validate: {
        validator: (v) => !v || /^https?:\/\/\S+$/i.test(v),
        message: 'Image URL must start with http:// or https://',
      },
    },
    prerequisites: { type: String, trim: true, default: '', maxlength: 1000 },
    learningOutcomes: { type: [String], default: [] },
  },
  { timestamps: true }
);

courseSchema.index({ title: 1, instructor: 1 });

module.exports = mongoose.model('Course', courseSchema);
module.exports.LEVELS = LEVELS;
