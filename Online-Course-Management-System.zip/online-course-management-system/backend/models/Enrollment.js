const mongoose = require('mongoose');

const STATUSES = ['Enrolled', 'In Progress', 'Completed', 'Cancelled'];

const enrollmentSchema = new mongoose.Schema(
  {
    studentName: { type: String, required: [true, 'Student name is required'], trim: true, minlength: [2, 'Name is too short'], maxlength: 100 },
    email: {
      type: String,
      required: [true, 'Email is required'],
      trim: true,
      lowercase: true,
      match: [/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, 'Please enter a valid email address'],
    },
    phone: {
      type: String,
      required: [true, 'Phone number is required'],
      trim: true,
      match: [/^\+?[0-9\s\-()]{7,20}$/, 'Please enter a valid phone number (7-20 digits)'],
    },
    course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: [true, 'Course is required'] },
    enrollmentDate: { type: Date, default: Date.now },
    status: {
      type: String,
      enum: { values: STATUSES, message: 'Invalid status' },
      default: 'Enrolled',
    },
  },
  { timestamps: true }
);

// One student (email) can enroll in a given course only once.
enrollmentSchema.index({ email: 1, course: 1 }, { unique: true });

module.exports = mongoose.model('Enrollment', enrollmentSchema);
module.exports.STATUSES = STATUSES;
