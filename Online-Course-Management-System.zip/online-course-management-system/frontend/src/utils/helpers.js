import axios from 'axios';

export const LEVELS = ['Beginner', 'Intermediate', 'Advanced'];
export const STATUSES = ['Enrolled', 'In Progress', 'Completed', 'Cancelled'];
export const DEFAULT_CATEGORIES = [
  'Web Development',
  'Data Science',
  'Artificial Intelligence',
  'UI/UX Design',
  'Cybersecurity',
  'Cloud Computing',
];

export const formatPrice = (value) =>
  Number(value) === 0
    ? 'Free'
    : new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);

export const formatDuration = (weeks) => `${weeks} ${Number(weeks) === 1 ? 'week' : 'weeks'}`;

export const formatDate = (value) =>
  value ? new Date(value).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '-';

export const toDateInput = (value) => (value ? new Date(value).toISOString().slice(0, 10) : '');

export const todayInput = () => new Date().toISOString().slice(0, 10);

// Turns any Axios/network error into a readable message (plus a list of field errors if the API sent them).
export const parseError = (error) => {
  if (axios.isCancel?.(error)) return { message: '', errors: [], status: 0, cancelled: true };
  if (error.response) {
    const { data, status } = error.response;
    return {
      message: data?.message || `Request failed (status ${status})`,
      errors: Array.isArray(data?.errors) ? data.errors : [],
      status,
    };
  }
  if (error.code === 'ECONNABORTED') {
    return { message: 'The server took too long to respond. Please try again.', errors: [], status: 0 };
  }
  return {
    message: 'Cannot reach the server. Make sure the backend is running on http://localhost:5000 and try again.',
    errors: [],
    status: 0,
  };
};

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
export const PHONE_RE = /^\+?[0-9\s\-()]{7,20}$/;
export const URL_RE = /^https?:\/\/\S+$/i;

// Shared by the enrollment form and the edit-enrollment dialog.
export const validateEnrollment = (v) => {
  const errors = {};
  if (!v.studentName.trim()) errors.studentName = 'Full name is required';
  else if (v.studentName.trim().length < 2) errors.studentName = 'Name must be at least 2 characters';
  if (!v.email.trim()) errors.email = 'Email is required';
  else if (!EMAIL_RE.test(v.email.trim())) errors.email = 'Enter a valid email address';
  if (!v.phone.trim()) errors.phone = 'Phone number is required';
  else if (!PHONE_RE.test(v.phone.trim())) errors.phone = 'Enter a valid phone number (7-20 digits; + - ( ) and spaces allowed)';
  if (!v.course) errors.course = 'Select a course';
  if (!STATUSES.includes(v.status)) errors.status = 'Select a valid status';
  if (!v.enrollmentDate) errors.enrollmentDate = 'Enrollment date is required';
  return errors;
};
