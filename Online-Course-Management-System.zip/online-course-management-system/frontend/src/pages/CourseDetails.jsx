import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, Clock, Signal, Tag, User, Users } from 'lucide-react';
import { getCourse } from '../api/courseApi';
import { formatDuration, formatPrice, parseError } from '../utils/helpers';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

export default function CourseDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notFound, setNotFound] = useState(false);

  const load = useCallback(async (signal) => {
    setLoading(true);
    setError('');
    setNotFound(false);
    try {
      const res = await getCourse(id, signal);
      setCourse(res.data);
    } catch (err) {
      const parsed = parseError(err);
      if (parsed.cancelled) return;
      if (parsed.status === 404 || parsed.status === 400) setNotFound(true);
      else setError(parsed.message);
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, [load]);

  if (loading) return <div className="container page"><Loading text="Loading course..." /></div>;

  if (notFound) {
    return (
      <div className="container page">
        <EmptyState title="Course not found" text="This course does not exist or may have been deleted.">
          <Link to="/courses" className="btn btn-primary btn-sm">Back to Courses</Link>
        </EmptyState>
      </div>
    );
  }

  if (error) return <div className="container page"><ErrorMessage message={error} onRetry={() => load()} /></div>;
  if (!course) return null;

  return (
    <div className="container page">
      <button type="button" className="link-back" onClick={() => navigate('/courses')}>
        <ArrowLeft size={16} /> Back to Courses
      </button>

      <div className="details-layout">
        <div className="details-main">
          <span className="badge badge-category static">{course.category}</span>
          <h1>{course.title}</h1>
          <p className="details-instructor"><User size={18} /> Taught by <strong>{course.instructor}</strong></p>

          {course.imageUrl && <img className="details-image" src={course.imageUrl} alt="" onError={(e) => { e.currentTarget.style.display = 'none'; }} />}

          <h2>About this course</h2>
          <p className="pre-wrap">{course.description}</p>

          <h2>What you will learn</h2>
          {course.learningOutcomes?.length > 0 ? (
            <ul className="check-list">
              {course.learningOutcomes.map((item) => (
                <li key={item}><CheckCircle2 size={18} /> {item}</li>
              ))}
            </ul>
          ) : (
            <p className="muted">Learning outcomes have not been added for this course.</p>
          )}

          <h2>Prerequisites</h2>
          <p className="pre-wrap">{course.prerequisites || 'No prerequisites listed.'}</p>
        </div>

        <aside className="details-side">
          <div className="price-big">{formatPrice(course.price)}</div>
          <ul className="fact-list">
            <li><Clock size={18} /> <span>Duration</span><strong>{formatDuration(course.durationWeeks)}</strong></li>
            <li><Signal size={18} /> <span>Level</span><strong>{course.level}</strong></li>
            <li><Tag size={18} /> <span>Category</span><strong>{course.category}</strong></li>
            <li><Users size={18} /> <span>Enrolled</span><strong>{course.enrollmentCount}</strong></li>
          </ul>
          <Link to={`/enroll?courseId=${course._id}`} className="btn btn-primary btn-block">Enroll Now</Link>
          <Link to="/courses" className="btn btn-outline btn-block">Back to Courses</Link>
        </aside>
      </div>
    </div>
  );
}
