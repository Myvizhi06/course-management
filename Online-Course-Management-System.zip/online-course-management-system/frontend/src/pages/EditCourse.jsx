import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { getCourse, updateCourse } from '../api/courseApi';
import { getStats } from '../api/dashboardApi';
import { parseError } from '../utils/helpers';
import Alert from '../components/Alert';
import CourseForm, { courseToForm } from '../components/CourseForm';
import EmptyState from '../components/EmptyState';
import ErrorMessage from '../components/ErrorMessage';
import Loading from '../components/Loading';

export default function EditCourse() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [notFound, setNotFound] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState({ message: '', errors: [] });
  const [success, setSuccess] = useState('');
  // Changing this key re-mounts the form so it shows the freshly saved values.
  const [formKey, setFormKey] = useState(0);

  const load = useCallback(async (signal) => {
    setLoading(true);
    setLoadError('');
    setNotFound(false);
    try {
      const res = await getCourse(id, signal);
      setCourse(res.data);
    } catch (err) {
      const parsed = parseError(err);
      if (parsed.cancelled) return;
      if (parsed.status === 404 || parsed.status === 400) setNotFound(true);
      else setLoadError(parsed.message);
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    getStats(controller.signal)
      .then((res) => setCategories(res.data.categories.map((c) => c.name)))
      .catch(() => {});
    return () => controller.abort();
  }, [load]);

  const handleSubmit = async (payload) => {
    setSubmitting(true);
    setSuccess('');
    setServerError({ message: '', errors: [] });
    try {
      const res = await updateCourse(id, payload);
      setCourse((prev) => ({ ...prev, ...res.data }));
      setFormKey((k) => k + 1);
      setSuccess('Course updated successfully.');
    } catch (err) {
      const parsed = parseError(err);
      if (parsed.status === 404) setNotFound(true);
      else setServerError({ message: parsed.message, errors: parsed.errors });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="container page"><Loading text="Loading course..." /></div>;

  if (notFound) {
    return (
      <div className="container page">
        <EmptyState title="Course not found" text="This course does not exist or has been deleted.">
          <Link to="/manage-courses" className="btn btn-primary btn-sm">Back to Manage Courses</Link>
        </EmptyState>
      </div>
    );
  }

  if (loadError) return <div className="container page"><ErrorMessage message={loadError} onRetry={() => load()} /></div>;
  if (!course) return null;

  return (
    <div className="container page narrow">
      <button type="button" className="link-back" onClick={() => navigate('/manage-courses')}>
        <ArrowLeft size={16} /> Back to Manage Courses
      </button>
      <div className="page-header">
        <h1>Edit Course</h1>
        <p>Update the details for <strong>{course.title}</strong>.</p>
      </div>
      {success && (
        <Alert type="success" message={success}>
          <p><Link to={`/courses/${course._id}`}>View course page</Link></p>
        </Alert>
      )}
      {serverError.message && <Alert type="error" message={serverError.message} errors={serverError.errors} />}
      <CourseForm
        key={formKey}
        initialValues={courseToForm(course)}
        categories={categories}
        submitLabel="Save Changes"
        submitting={submitting}
        onSubmit={handleSubmit}
        onCancel={() => navigate('/manage-courses')}
      />
    </div>
  );
}
