import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Award, BookOpen, Layers, ShieldCheck, Sparkles, Users, UserCheck } from 'lucide-react';
import { getCourses } from '../api/courseApi';
import { getStats } from '../api/dashboardApi';
import { parseError } from '../utils/helpers';
import CourseCard from '../components/CourseCard';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

const reasons = [
  { icon: Award, title: 'Expert instructors', text: 'Every course lists its instructor so you know who is teaching you.' },
  { icon: Sparkles, title: 'Learn at every level', text: 'Pick Beginner, Intermediate, or Advanced courses that match your experience.' },
  { icon: ShieldCheck, title: 'Clear information', text: 'See prerequisites, duration, price, and learning outcomes before you enroll.' },
  { icon: UserCheck, title: 'Simple enrollment', text: 'Register in a minute and track or update your enrollment any time.' },
];

export default function Home() {
  const [courses, setCourses] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async (signal) => {
    setLoading(true);
    setError('');
    try {
      const [courseRes, statsRes] = await Promise.all([getCourses({}, signal), getStats(signal)]);
      setCourses(courseRes.data);
      setStats(statsRes.data);
    } catch (err) {
      const parsed = parseError(err);
      if (!parsed.cancelled) setError(parsed.message);
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, [load]);

  const featured = courses.slice(0, 3);

  return (
    <>
      <section className="hero">
        <div className="container hero-inner">
          <div className="hero-text">
            <span className="eyebrow">Online learning platform</span>
            <h1>Learn New Skills. Build Your Future.</h1>
            <p>
              CourseHub brings courses in web development, data science, AI, design, security, and cloud
              together in one place. Explore, enroll, and keep track of your learning.
            </p>
            <div className="hero-actions">
              <Link to="/courses" className="btn btn-accent btn-lg">Explore Courses <ArrowRight size={18} /></Link>
              <Link to="/enroll" className="btn btn-ghost btn-lg">Enroll Now</Link>
            </div>
          </div>
          <div className="hero-panel" aria-label="Platform statistics">
            {stats ? (
              <div className="stat-grid">
                <div className="stat"><BookOpen size={22} /><strong>{stats.totalCourses}</strong><span>Courses</span></div>
                <div className="stat"><Users size={22} /><strong>{stats.totalEnrollments}</strong><span>Enrollments</span></div>
                <div className="stat"><Award size={22} /><strong>{stats.totalInstructors}</strong><span>Instructors</span></div>
                <div className="stat"><Layers size={22} /><strong>{stats.totalCategories}</strong><span>Categories</span></div>
              </div>
            ) : (
              <p className="hero-panel-note">{loading ? 'Loading live statistics...' : 'Statistics are unavailable right now.'}</p>
            )}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <h2>Featured courses</h2>
              <p>The newest courses added to CourseHub.</p>
            </div>
            <Link to="/courses" className="link-arrow">View all courses <ArrowRight size={16} /></Link>
          </div>

          {loading && <Loading text="Loading courses..." />}
          {!loading && error && <ErrorMessage message={error} onRetry={() => load()} />}
          {!loading && !error && featured.length === 0 && (
            <EmptyState title="No courses yet" text="Courses will appear here as soon as they are added.">
              <Link to="/manage-courses/new" className="btn btn-primary btn-sm">Add the first course</Link>
            </EmptyState>
          )}
          {!loading && !error && featured.length > 0 && (
            <div className="course-grid">
              {featured.map((c) => <CourseCard key={c._id} course={c} />)}
            </div>
          )}
        </div>
      </section>

      <section className="section section-alt">
        <div className="container">
          <div className="section-head">
            <div>
              <h2>Browse by category</h2>
              <p>Categories are built from the courses currently in the database.</p>
            </div>
          </div>
          {stats && stats.categories.length > 0 ? (
            <div className="category-grid">
              {stats.categories.map((cat) => (
                <Link key={cat.name} to={`/courses?category=${encodeURIComponent(cat.name)}`} className="category-card">
                  <span className="category-icon">{cat.name.charAt(0)}</span>
                  <strong>{cat.name}</strong>
                  <span className="muted">{cat.count} {cat.count === 1 ? 'course' : 'courses'}</span>
                </Link>
              ))}
            </div>
          ) : (
            !loading && !error && <EmptyState title="No categories yet" text="Add a course to create its category." />
          )}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head center">
            <div>
              <h2>Why choose CourseHub?</h2>
              <p>Everything you need to find the right course and start learning.</p>
            </div>
          </div>
          <div className="reason-grid">
            {reasons.map(({ icon: Icon, title, text }) => (
              <div className="reason-card" key={title}>
                <span className="reason-icon"><Icon size={24} /></span>
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="cta">
            <h2>Ready to start learning?</h2>
            <p>Choose a course and enroll in under a minute.</p>
            <div className="hero-actions">
              <Link to="/enroll" className="btn btn-accent btn-lg">Enroll in a Course</Link>
              <Link to="/courses" className="btn btn-ghost btn-lg">Browse Courses</Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
