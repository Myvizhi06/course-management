import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { createCourse } from '../api/courseApi';
import { getStats } from '../api/dashboardApi';
import { parseError } from '../utils/helpers';
import Alert from '../components/Alert';
import CourseForm from '../components/CourseForm';

export default function AddCourse() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState({ message: '', errors: [] });

  useEffect(() => {
    const controller = new AbortController();
    getStats(controller.signal)
      .then((res) => setCategories(res.data.categories.map((c) => c.name)))
      .catch(() => {});
    return () => controller.abort();
  }, []);

  const handleSubmit = async (payload) => {
    setSubmitting(true);
    setServerError({ message: '', errors: [] });
    try {
      const res = await createCourse(payload);
      navigate('/manage-courses', { state: { message: `Course "${res.data.title}" was created successfully.` } });
    } catch (err) {
      const parsed = parseError(err);
      setServerError({ message: parsed.message, errors: parsed.errors });
      setSubmitting(false);
    }
  };

  return (
    <div className="container page narrow">
      <button type="button" className="link-back" onClick={() => navigate('/manage-courses')}>
        <ArrowLeft size={16} /> Back to Manage Courses
      </button>
      <div className="page-header">
        <h1>Add Course</h1>
        <p>Create a new course. It is saved to MongoDB and appears in the course list immediately.</p>
      </div>
      {serverError.message && <Alert type="error" message={serverError.message} errors={serverError.errors} />}
      <CourseForm
        categories={categories}
        submitLabel="Create Course"
        submitting={submitting}
        onSubmit={handleSubmit}
        onCancel={() => navigate('/manage-courses')}
      />
    </div>
  );
}
