import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Pencil, Search, Trash2 } from 'lucide-react';
import { getCourses } from '../api/courseApi';
import { deleteEnrollment, getEnrollments, updateEnrollment } from '../api/enrollmentApi';
import { STATUSES, formatDate, parseError, toDateInput, validateEnrollment } from '../utils/helpers';
import useDebounce from '../hooks/useDebounce';
import Alert from '../components/Alert';
import ConfirmDialog from '../components/ConfirmDialog';
import EmptyState from '../components/EmptyState';
import ErrorMessage from '../components/ErrorMessage';
import Loading from '../components/Loading';
import Modal from '../components/Modal';

function EditEnrollmentModal({ enrollment, courses, onClose, onSaved }) {
  const [values, setValues] = useState({
    studentName: enrollment.studentName,
    email: enrollment.email,
    phone: enrollment.phone,
    course: enrollment.course?._id || '',
    status: enrollment.status,
    enrollmentDate: toDateInput(enrollment.enrollmentDate),
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState({ message: '', errors: [] });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (submitting) return;
    setServerError({ message: '', errors: [] });
    const found = validateEnrollment(values);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      await updateEnrollment(enrollment._id, {
        studentName: values.studentName.trim(),
        email: values.email.trim(),
        phone: values.phone.trim(),
        course: values.course,
        status: values.status,
        enrollmentDate: values.enrollmentDate,
      });
      await onSaved();
    } catch (err) {
      const parsed = parseError(err);
      setServerError({ message: parsed.message, errors: parsed.errors });
      setSubmitting(false);
    }
  };

  const field = (name, label, input) => (
    <div className={`form-group ${errors[name] ? 'has-error' : ''}`}>
      <label htmlFor={`edit-${name}`}>{label}</label>
      {input}
      {errors[name] && <small className="field-error">{errors[name]}</small>}
    </div>
  );

  return (
    <Modal title="Edit enrollment" onClose={submitting ? () => {} : onClose} wide>
      <form onSubmit={handleSubmit} noValidate>
        {serverError.message && <Alert type="error" message={serverError.message} errors={serverError.errors} />}
        {field('studentName', 'Full name *', <input id="edit-studentName" name="studentName" value={values.studentName} onChange={handleChange} maxLength={100} />)}
        <div className="form-row">
          {field('email', 'Email *', <input id="edit-email" name="email" type="email" value={values.email} onChange={handleChange} />)}
          {field('phone', 'Phone *', <input id="edit-phone" name="phone" type="tel" value={values.phone} onChange={handleChange} />)}
        </div>
        {field(
          'course',
          'Course *',
          <select id="edit-course" name="course" value={values.course} onChange={handleChange}>
            <option value="">Select a course</option>
            {courses.map((c) => <option key={c._id} value={c._id}>{c.title}</option>)}
          </select>
        )}
        <div className="form-row">
          {field('enrollmentDate', 'Enrollment date *', <input id="edit-enrollmentDate" name="enrollmentDate" type="date" value={values.enrollmentDate} onChange={handleChange} />)}
          {field(
            'status',
            'Status *',
            <select id="edit-status" name="status" value={values.status} onChange={handleChange}>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          )}
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-outline" onClick={onClose} disabled={submitting}>Cancel</button>
          <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? 'Saving...' : 'Save changes'}</button>
        </div>
      </form>
    </Modal>
  );
}

export default function Enrollments() {
  const [enrollments, setEnrollments] = useState([]);
  const [courses, setCourses] = useState([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [courseId, setCourseId] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [deleteError, setDeleteError] = useState('');
  const debouncedSearch = useDebounce(search);

  useEffect(() => {
    const controller = new AbortController();
    getCourses({}, controller.signal).then((res) => setCourses(res.data)).catch(() => {});
    return () => controller.abort();
  }, []);

  const load = useCallback(async (signal) => {
    setLoading(true);
    setError('');
    try {
      const res = await getEnrollments({ search: debouncedSearch, status, courseId }, signal);
      setEnrollments(res.data);
    } catch (err) {
      const parsed = parseError(err);
      if (!parsed.cancelled) setError(parsed.message);
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [debouncedSearch, status, courseId]);

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, [load]);

  const handleSaved = async () => {
    setEditing(null);
    setNotice('Enrollment updated successfully.');
    await load();
  };

  const confirmDelete = async () => {
    setDeleteBusy(true);
    setDeleteError('');
    try {
      await deleteEnrollment(deleting._id);
      setDeleting(null);
      setNotice('Enrollment deleted successfully.');
      await load();
    } catch (err) {
      setDeleteError(parseError(err).message);
    } finally {
      setDeleteBusy(false);
    }
  };

  const hasFilters = Boolean(debouncedSearch || status || courseId);

  return (
    <div className="container page">
      <div className="page-header row-between">
        <div>
          <h1>My Enrollments</h1>
          <p>Search, edit, and remove enrollment records.</p>
        </div>
        <Link to="/enroll" className="btn btn-primary">New Enrollment</Link>
      </div>

      <Alert type="info-note" message="">
        <span className="note-text">
          Demo note: this college project has no login, so every enrollment is visible here. A production
          application would require authentication and authorization so students only see their own records.
        </span>
      </Alert>

      {notice && <Alert type="success" message={notice} />}

      <div className="toolbar">
        <div className="search-box">
          <Search size={18} />
          <input
            type="search"
            placeholder="Search by name, email, phone, or course"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search enrollments"
          />
        </div>
        <select value={courseId} onChange={(e) => setCourseId(e.target.value)} aria-label="Filter by course">
          <option value="">All courses</option>
          {courses.map((c) => <option key={c._id} value={c._id}>{c.title}</option>)}
        </select>
        <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status">
          <option value="">All statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      {loading && <Loading text="Loading enrollments..." />}
      {!loading && error && <ErrorMessage message={error} onRetry={() => load()} />}
      {!loading && !error && enrollments.length === 0 && (
        <EmptyState
          title={hasFilters ? 'No enrollments match your filters' : 'No enrollments yet'}
          text={hasFilters ? 'Try changing or clearing the filters.' : 'Enroll a student to see records here.'}
        >
          {!hasFilters && <Link to="/enroll" className="btn btn-primary btn-sm">Enroll a student</Link>}
        </EmptyState>
      )}

      {!loading && !error && enrollments.length > 0 && (
        <>
          <p className="result-count">{enrollments.length} {enrollments.length === 1 ? 'enrollment' : 'enrollments'}</p>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Student</th>
                  <th>Contact</th>
                  <th>Course</th>
                  <th>Enrolled on</th>
                  <th>Status</th>
                  <th className="actions-col">Actions</th>
                </tr>
              </thead>
              <tbody>
                {enrollments.map((en) => (
                  <tr key={en._id}>
                    <td data-label="Student"><strong>{en.studentName}</strong></td>
                    <td data-label="Contact">{en.email}<br /><span className="muted">{en.phone}</span></td>
                    <td data-label="Course">{en.course?.title || <span className="muted">Course unavailable</span>}</td>
                    <td data-label="Enrolled on">{formatDate(en.enrollmentDate)}</td>
                    <td data-label="Status"><span className={`status status-${en.status.replace(/\s+/g, '-').toLowerCase()}`}>{en.status}</span></td>
                    <td className="actions-col" data-label="Actions">
                      <button type="button" className="btn btn-outline btn-sm" onClick={() => { setNotice(''); setEditing(en); }}>
                        <Pencil size={14} /> Edit
                      </button>
                      <button type="button" className="btn btn-danger-outline btn-sm" onClick={() => { setNotice(''); setDeleteError(''); setDeleting(en); }}>
                        <Trash2 size={14} /> Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {editing && <EditEnrollmentModal enrollment={editing} courses={courses} onClose={() => setEditing(null)} onSaved={handleSaved} />}
      {deleting && (
        <ConfirmDialog
          title="Delete enrollment?"
          message={`This will permanently remove ${deleting.studentName}'s enrollment${deleting.course ? ` in "${deleting.course.title}"` : ''}.`}
          busy={deleteBusy}
          error={deleteError}
          onConfirm={confirmDelete}
          onCancel={() => setDeleting(null)}
        />
      )}
    </div>
  );
}
