import { useCallback, useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { BookOpen, Pencil, Plus, Search, Trash2, Users } from 'lucide-react';
import { deleteCourse, getCourses } from '../api/courseApi';
import { getStats } from '../api/dashboardApi';
import { formatDuration, formatPrice, parseError } from '../utils/helpers';
import useDebounce from '../hooks/useDebounce';
import Alert from '../components/Alert';
import ConfirmDialog from '../components/ConfirmDialog';
import EmptyState from '../components/EmptyState';
import ErrorMessage from '../components/ErrorMessage';
import Loading from '../components/Loading';

export default function ManageCourses() {
  const location = useLocation();
  const navigate = useNavigate();
  const [courses, setCourses] = useState([]);
  const [stats, setStats] = useState(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState(location.state?.message || '');
  const [deleting, setDeleting] = useState(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [deleteError, setDeleteError] = useState('');
  const debouncedSearch = useDebounce(search);

  // Clear the one-time redirect message from history so it does not reappear on refresh.
  useEffect(() => {
    if (location.state?.message) navigate(location.pathname, { replace: true, state: null });
  }, [location, navigate]);

  const load = useCallback(async (signal) => {
    setLoading(true);
    setError('');
    try {
      const [courseRes, statsRes] = await Promise.all([
        getCourses({ search: debouncedSearch, category }, signal),
        getStats(signal),
      ]);
      setCourses(courseRes.data);
      setStats(statsRes.data);
    } catch (err) {
      const parsed = parseError(err);
      if (!parsed.cancelled) setError(parsed.message);
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [debouncedSearch, category]);

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, [load]);

  const confirmDelete = async () => {
    setDeleteBusy(true);
    setDeleteError('');
    try {
      await deleteCourse(deleting._id);
      setNotice(`"${deleting.title}" was deleted.`);
      setDeleting(null);
      await load();
    } catch (err) {
      // e.g. 409 when the course still has enrollments
      setDeleteError(parseError(err).message);
    } finally {
      setDeleteBusy(false);
    }
  };

  const hasFilters = Boolean(debouncedSearch || category);

  return (
    <div className="container page">
      <div className="page-header row-between">
        <div>
          <h1>Manage Courses</h1>
          <p>Add, edit, and delete the courses stored in MongoDB.</p>
        </div>
        <Link to="/manage-courses/new" className="btn btn-primary"><Plus size={18} /> Add Course</Link>
      </div>

      <Alert type="info-note" message="">
        <span className="note-text">
          Demo dashboard: authentication and role-based authorization are not implemented in this college
          project, so anyone who can open this page can change courses.
        </span>
      </Alert>

      {notice && <Alert type="success" message={notice} />}

      <div className="stat-cards">
        <div className="stat-card">
          <span className="stat-card-icon"><BookOpen size={22} /></span>
          <div><strong>{stats ? stats.totalCourses : '-'}</strong><span>Total courses</span></div>
        </div>
        <div className="stat-card">
          <span className="stat-card-icon teal"><Users size={22} /></span>
          <div><strong>{stats ? stats.totalEnrollments : '-'}</strong><span>Total enrollments</span></div>
        </div>
      </div>

      <div className="toolbar">
        <div className="search-box">
          <Search size={18} />
          <input type="search" placeholder="Search courses" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search courses" />
        </div>
        <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by category">
          <option value="">All categories</option>
          {(stats?.categories || []).map((c) => <option key={c.name} value={c.name}>{c.name}</option>)}
        </select>
      </div>

      {loading && <Loading text="Loading courses..." />}
      {!loading && error && <ErrorMessage message={error} onRetry={() => load()} />}
      {!loading && !error && courses.length === 0 && (
        <EmptyState
          title={hasFilters ? 'No courses match your filters' : 'No courses yet'}
          text={hasFilters ? 'Try a different search or category.' : 'Add your first course, or run "npm run seed" in the backend folder.'}
        >
          {!hasFilters && <Link to="/manage-courses/new" className="btn btn-primary btn-sm">Add Course</Link>}
        </EmptyState>
      )}

      {!loading && !error && courses.length > 0 && (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Course</th>
                <th>Category</th>
                <th>Level</th>
                <th>Duration</th>
                <th>Price</th>
                <th>Enrolled</th>
                <th className="actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {courses.map((c) => (
                <tr key={c._id}>
                  <td data-label="Course"><Link to={`/courses/${c._id}`} className="table-link"><strong>{c.title}</strong></Link><br /><span className="muted">{c.instructor}</span></td>
                  <td data-label="Category">{c.category}</td>
                  <td data-label="Level">{c.level}</td>
                  <td data-label="Duration">{formatDuration(c.durationWeeks)}</td>
                  <td data-label="Price">{formatPrice(c.price)}</td>
                  <td data-label="Enrolled">{c.enrollmentCount}</td>
                  <td className="actions-col" data-label="Actions">
                    <Link to={`/manage-courses/${c._id}/edit`} className="btn btn-outline btn-sm"><Pencil size={14} /> Edit</Link>
                    <button type="button" className="btn btn-danger-outline btn-sm" onClick={() => { setNotice(''); setDeleteError(''); setDeleting(c); }}>
                      <Trash2 size={14} /> Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {deleting && (
        <ConfirmDialog
          title="Delete course?"
          message={`Delete "${deleting.title}"? This cannot be undone. A course that still has enrollments cannot be deleted.`}
          busy={deleteBusy}
          error={deleteError}
          onConfirm={confirmDelete}
          onCancel={() => setDeleting(null)}
        />
      )}
    </div>
  );
}
