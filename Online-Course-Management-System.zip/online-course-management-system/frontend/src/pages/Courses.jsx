import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import { getCourses } from '../api/courseApi';
import { getStats } from '../api/dashboardApi';
import { LEVELS, parseError } from '../utils/helpers';
import useDebounce from '../hooks/useDebounce';
import CourseCard from '../components/CourseCard';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

export default function Courses() {
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [level, setLevel] = useState('');
  const [categories, setCategories] = useState([]);
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const debouncedSearch = useDebounce(search);

  // Category dropdown options come from the database.
  useEffect(() => {
    const controller = new AbortController();
    getStats(controller.signal)
      .then((res) => setCategories(res.data.categories.map((c) => c.name)))
      .catch(() => {});
    return () => controller.abort();
  }, []);

  const load = useCallback(async (signal) => {
    setLoading(true);
    setError('');
    try {
      const res = await getCourses({ search: debouncedSearch, category, level }, signal);
      setCourses(res.data);
    } catch (err) {
      const parsed = parseError(err);
      if (!parsed.cancelled) setError(parsed.message);
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [debouncedSearch, category, level]);

  useEffect(() => {
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, [load]);

  const hasFilters = Boolean(debouncedSearch || category || level);
  const clearFilters = () => {
    setSearch('');
    setCategory('');
    setLevel('');
  };

  return (
    <div className="container page">
      <div className="page-header">
        <h1>All Courses</h1>
        <p>Search the catalog and filter by category or level to find the right course.</p>
      </div>

      <div className="toolbar">
        <div className="search-box">
          <Search size={18} />
          <input
            type="search"
            placeholder="Search by title, instructor, or keyword"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search courses"
          />
        </div>
        <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by category">
          <option value="">All categories</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={level} onChange={(e) => setLevel(e.target.value)} aria-label="Filter by level">
          <option value="">All levels</option>
          {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
        </select>
      </div>

      {loading && <Loading text="Loading courses..." />}
      {!loading && error && <ErrorMessage message={error} onRetry={() => load()} />}
      {!loading && !error && courses.length === 0 && (
        <EmptyState
          title={hasFilters ? 'No courses match your search' : 'No courses available yet'}
          text={hasFilters ? 'Try a different keyword or clear the filters.' : 'Add a course from the Manage Courses page or run the seed script.'}
        >
          {hasFilters && <button type="button" className="btn btn-outline btn-sm" onClick={clearFilters}>Clear filters</button>}
        </EmptyState>
      )}
      {!loading && !error && courses.length > 0 && (
        <>
          <p className="result-count">{courses.length} {courses.length === 1 ? 'course' : 'courses'} found</p>
          <div className="course-grid">
            {courses.map((c) => <CourseCard key={c._id} course={c} />)}
          </div>
        </>
      )}
    </div>
  );
}
