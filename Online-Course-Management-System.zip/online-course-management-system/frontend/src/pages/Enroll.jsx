import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { getCourses } from '../api/courseApi';
import { createEnrollment } from '../api/enrollmentApi';
import { STATUSES, parseError, todayInput, validateEnrollment } from '../utils/helpers';
import Alert from '../components/Alert';
import Loading from '../components/Loading';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

const blankForm = (courseId = '') => ({
  studentName: '',
  email: '',
  phone: '',
  course: courseId,
  status: 'Enrolled',
  enrollmentDate: todayInput(),
});

export default function Enroll() {
  const [searchParams] = useSearchParams();
  const presetCourse = searchParams.get('courseId') || '';

  const [courses, setCourses] = useState([]);
  const [loadingCourses, setLoadingCourses] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [reloadKey, setReloadKey] = useState(0);

  const [values, setValues] = useState(blankForm(presetCourse));
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState({ message: '', errors: [] });
  const [success, setSuccess] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    setLoadingCourses(true);
    setLoadError('');
    getCourses({}, controller.signal)
      .then((res) => {
        setCourses(res.data);
        // Ignore a preset course id that no longer exists.
        setValues((prev) => (res.data.some((c) => c._id === prev.course) ? prev : { ...prev, course: '' }));
      })
      .catch((err) => {
        const parsed = parseError(err);
        if (!parsed.cancelled) setLoadError(parsed.message);
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingCourses(false);
      });
    return () => controller.abort();
  }, [reloadKey]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (submitting) return;
    setSuccess(null);
    setServerError({ message: '', errors: [] });

    const found = validateEnrollment(values);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    setSubmitting(true);
    try {
      const res = await createEnrollment({
        studentName: values.studentName.trim(),
        email: values.email.trim(),
        phone: values.phone.trim(),
        course: values.course,
        status: values.status,
        enrollmentDate: values.enrollmentDate,
      });
      // Success is shown only after the backend has confirmed the save.
      setSuccess(res.data);
      setValues(blankForm());
    } catch (err) {
      const parsed = parseError(err);
      setServerError({ message: parsed.message, errors: parsed.errors });
    } finally {
      setSubmitting(false);
    }
  };

  const field = (name, label, input) => (
    <div className={`form-group ${errors[name] ? 'has-error' : ''}`}>
      <label htmlFor={name}>{label}</label>
      {input}
      {errors[name] && <small className="field-error">{errors[name]}</small>}
    </div>
  );

  return (
    <div className="container page narrow">
      <div className="page-header">
        <h1>Enroll in a Course</h1>
        <p>Fill in your details and choose a course to register.</p>
      </div>

      {success && (
        <Alert type="success" message="Enrollment successful!">
          <p>
            {success.studentName} is now registered for <strong>{success.course?.title}</strong>.{' '}
            <Link to="/enrollments">View my enrollments</Link>
          </p>
        </Alert>
      )}
      {serverError.message && <Alert type="error" message={serverError.message} errors={serverError.errors} />}

      {loadingCourses && <Loading text="Loading courses..." />}
      {!loadingCourses && loadError && <ErrorMessage message={loadError} onRetry={() => setReloadKey((k) => k + 1)} />}
      {!loadingCourses && !loadError && courses.length === 0 && (
        <EmptyState title="No courses to enroll in" text="Add a course first, then come back to enroll.">
          <Link to="/manage-courses/new" className="btn btn-primary btn-sm">Add a course</Link>
        </EmptyState>
      )}

      {!loadingCourses && !loadError && courses.length > 0 && (
        <form className="form-card" onSubmit={handleSubmit} noValidate>
          {field('studentName', 'Full name *', <input id="studentName" name="studentName" value={values.studentName} onChange={handleChange} maxLength={100} autoComplete="name" />)}
          <div className="form-row">
            {field('email', 'Email address *', <input id="email" name="email" type="email" value={values.email} onChange={handleChange} autoComplete="email" />)}
            {field('phone', 'Phone number *', <input id="phone" name="phone" type="tel" value={values.phone} onChange={handleChange} placeholder="+91 98765 43210" autoComplete="tel" />)}
          </div>
          {field(
            'course',
            'Course *',
            <select id="course" name="course" value={values.course} onChange={handleChange}>
              <option value="">Select a course</option>
              {courses.map((c) => <option key={c._id} value={c._id}>{c.title}</option>)}
            </select>
          )}
          <div className="form-row">
            {field('enrollmentDate', 'Enrollment date *', <input id="enrollmentDate" name="enrollmentDate" type="date" value={values.enrollmentDate} onChange={handleChange} />)}
            {field(
              'status',
              'Enrollment status *',
              <select id="status" name="status" value={values.status} onChange={handleChange}>
                {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            )}
          </div>
          <div className="form-actions">
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Submitting...' : 'Enroll Now'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
