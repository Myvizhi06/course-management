import { Link } from 'react-router-dom';
import { Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="container page not-found">
      <div className="not-found-code">404</div>
      <h1>Page not found</h1>
      <p>The page you are looking for does not exist or has been moved.</p>
      <Link to="/" className="btn btn-primary"><Home size={18} /> Back to Home</Link>
    </div>
  );
}
