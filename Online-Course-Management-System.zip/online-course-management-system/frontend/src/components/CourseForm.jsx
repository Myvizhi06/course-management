import { useState } from 'react';
import { DEFAULT_CATEGORIES, LEVELS, URL_RE } from '../utils/helpers';

export const emptyCourse = {
  title: '',
  description: '',
  instructor: '',
  category: '',
  level: 'Beginner',
  durationWeeks: '',
  price: '',
  imageUrl: '',
  prerequisites: '',
  learningOutcomes: '',
};

// Convert a course returned by the API into the string values the controlled inputs need.
export const courseToForm = (course) => ({
  title: course.title || '',
  description: course.description || '',
  instructor: course.instructor || '',
  category: course.category || '',
  level: course.level || 'Beginner',
  durationWeeks: String(course.durationWeeks ?? ''),
  price: String(course.price ?? ''),
  imageUrl: course.imageUrl || '',
  prerequisites: course.prerequisites || '',
  learningOutcomes: (course.learningOutcomes || []).join('\n'),
});

export const validateCourse = (v) => {
  const errors = {};
  if (!v.title.trim()) errors.title = 'Course title is required';
  if (!v.description.trim()) errors.description = 'Course description is required';
  if (!v.instructor.trim()) errors.instructor = 'Instructor name is required';
  if (!v.category.trim()) errors.category = 'Category is required';
  if (!LEVELS.includes(v.level)) errors.level = 'Select a valid level';

  const weeks = Number(v.durationWeeks);
  if (v.durationWeeks === '') errors.durationWeeks = 'Duration is required';
  else if (!Number.isInteger(weeks) || weeks < 1 || weeks > 520) errors.durationWeeks = 'Duration must be a whole number of weeks (1 or more)';

  const price = Number(v.price);
  if (v.price === '') errors.price = 'Price is required';
  else if (Number.isNaN(price) || price < 0) errors.price = 'Price must be a number that is 0 or more';

  if (v.imageUrl.trim() && !URL_RE.test(v.imageUrl.trim())) errors.imageUrl = 'Image URL must start with http:// or https://';
  return errors;
};

export default function CourseForm({ initialValues = emptyCourse, categories = [], submitLabel, submitting, onSubmit, onCancel }) {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});

  const categoryOptions = [...new Set([...DEFAULT_CATEGORIES, ...categories])].sort();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (submitting) return;
    const found = validateCourse(values);
    setErrors(found);
    if (Object.keys(found).length > 0) return;
    onSubmit({
      title: values.title.trim(),
      description: values.description.trim(),
      instructor: values.instructor.trim(),
      category: values.category.trim(),
      level: values.level,
      durationWeeks: Number(values.durationWeeks),
      price: Number(values.price),
      imageUrl: values.imageUrl.trim(),
      prerequisites: values.prerequisites.trim(),
      learningOutcomes: values.learningOutcomes.split('\n').map((l) => l.trim()).filter(Boolean),
    });
  };

  const field = (name, label, input, hint) => (
    <div className={`form-group ${errors[name] ? 'has-error' : ''}`}>
      <label htmlFor={name}>{label}</label>
      {input}
      {hint && !errors[name] && <small className="hint">{hint}</small>}
      {errors[name] && <small className="field-error">{errors[name]}</small>}
    </div>
  );

  return (
    <form className="form-card" onSubmit={handleSubmit} noValidate>
      {field('title', 'Course title *', <input id="title" name="title" value={values.title} onChange={handleChange} maxLength={150} placeholder="e.g. Introduction to Python" />)}
      {field('description', 'Course description *', <textarea id="description" name="description" rows={5} value={values.description} onChange={handleChange} maxLength={5000} placeholder="What is this course about?" />)}

      <div className="form-row">
        {field('instructor', 'Instructor name *', <input id="instructor" name="instructor" value={values.instructor} onChange={handleChange} maxLength={100} />)}
        {field(
          'category',
          'Category *',
          <>
            <input id="category" name="category" list="category-options" value={values.category} onChange={handleChange} maxLength={60} placeholder="Choose or type a category" />
            <datalist id="category-options">
              {categoryOptions.map((c) => <option key={c} value={c} />)}
            </datalist>
          </>
        )}
      </div>

      <div className="form-row three">
        {field(
          'level',
          'Level *',
          <select id="level" name="level" value={values.level} onChange={handleChange}>
            {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
        )}
        {field('durationWeeks', 'Duration (weeks) *', <input id="durationWeeks" name="durationWeeks" type="number" min="1" step="1" value={values.durationWeeks} onChange={handleChange} placeholder="e.g. 8" />)}
        {field('price', 'Price (INR) *', <input id="price" name="price" type="number" min="0" step="0.01" value={values.price} onChange={handleChange} placeholder="0 for a free course" />)}
      </div>

      {field('imageUrl', 'Course image URL (optional)', <input id="imageUrl" name="imageUrl" type="url" value={values.imageUrl} onChange={handleChange} placeholder="https://example.com/image.jpg" />)}
      {field('prerequisites', 'Prerequisites (optional)', <textarea id="prerequisites" name="prerequisites" rows={2} value={values.prerequisites} onChange={handleChange} maxLength={1000} />)}
      {field('learningOutcomes', 'Learning outcomes (optional)', <textarea id="learningOutcomes" name="learningOutcomes" rows={4} value={values.learningOutcomes} onChange={handleChange} />, 'Write one outcome per line.')}

      <div className="form-actions">
        {onCancel && (
          <button type="button" className="btn btn-outline" onClick={onCancel} disabled={submitting}>Cancel</button>
        )}
        <button type="submit" className="btn btn-primary" disabled={submitting}>
          {submitting ? 'Saving...' : submitLabel}
        </button>
      </div>
    </form>
  );
}
