import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, Signal, User } from 'lucide-react';
import { formatDuration, formatPrice } from '../utils/helpers';

export default function CourseCard({ course }) {
  const [imageFailed, setImageFailed] = useState(false);
  const showImage = course.imageUrl && !imageFailed;

  return (
    <article className="course-card">
      <div className="course-card-media">
        {showImage ? (
          <img src={course.imageUrl} alt="" loading="lazy" onError={() => setImageFailed(true)} />
        ) : (
          <div className="course-card-placeholder" aria-hidden="true">{course.category?.charAt(0) || 'C'}</div>
        )}
        <span className="badge badge-category">{course.category}</span>
      </div>

      <div className="course-card-body">
        <h3 className="course-card-title">{course.title}</h3>
        <p className="course-card-instructor"><User size={15} /> {course.instructor}</p>
        <p className="course-card-desc">{course.description}</p>

        <div className="course-card-meta">
          <span><Clock size={15} /> {formatDuration(course.durationWeeks)}</span>
          <span><Signal size={15} /> {course.level}</span>
        </div>

        <div className="course-card-footer">
          <span className="price">{formatPrice(course.price)}</span>
          <div className="card-actions">
            <Link to={`/courses/${course._id}`} className="btn btn-outline btn-sm">View Details</Link>
            <Link to={`/enroll?courseId=${course._id}`} className="btn btn-primary btn-sm">Enroll Now</Link>
          </div>
        </div>
      </div>
    </article>
  );
}
