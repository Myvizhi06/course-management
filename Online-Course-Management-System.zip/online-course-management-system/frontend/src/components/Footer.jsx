import { Link } from 'react-router-dom';
import { GraduationCap } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <div className="brand brand-light">
            <span className="brand-icon"><GraduationCap size={22} /></span>
            CourseHub
          </div>
          <p className="footer-text">
            A college demonstration of an online course management system built with React, Express, and MongoDB.
          </p>
        </div>
        <div>
          <h4>Explore</h4>
          <Link to="/">Home</Link>
          <Link to="/courses">All Courses</Link>
          <Link to="/enroll">Enroll in a Course</Link>
        </div>
        <div>
          <h4>Manage</h4>
          <Link to="/enrollments">My Enrollments</Link>
          <Link to="/manage-courses">Manage Courses</Link>
          <Link to="/manage-courses/new">Add a Course</Link>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>&copy; {new Date().getFullYear()} CourseHub. FSWD Lab Project - AppTailor: Stitch Your App.</span>
      </div>
    </footer>
  );
}
