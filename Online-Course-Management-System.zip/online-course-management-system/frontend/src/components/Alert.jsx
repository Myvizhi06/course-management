import { AlertCircle, CheckCircle2 } from 'lucide-react';

// type: "success" | "error". "errors" is an optional list of field-level messages.
export default function Alert({ type = 'success', message, errors = [], children }) {
  if (!message && !children) return null;
  const Icon = type === 'success' ? CheckCircle2 : AlertCircle;
  return (
    <div className={`alert alert-${type}`} role={type === 'error' ? 'alert' : 'status'}>
      <Icon size={20} className="alert-icon" />
      <div>
        {message && <strong>{message}</strong>}
        {errors.length > 0 && (
          <ul>
            {errors.map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        )}
        {children}
      </div>
    </div>
  );
}
