import Modal from './Modal';
import Alert from './Alert';

export default function ConfirmDialog({ title, message, confirmLabel = 'Delete', busy = false, error = '', onConfirm, onCancel }) {
  return (
    <Modal title={title} onClose={busy ? () => {} : onCancel}>
      <p className="confirm-text">{message}</p>
      {error && <Alert type="error" message={error} />}
      <div className="form-actions">
        <button type="button" className="btn btn-outline" onClick={onCancel} disabled={busy}>
          Cancel
        </button>
        <button type="button" className="btn btn-danger" onClick={onConfirm} disabled={busy}>
          {busy ? 'Working...' : confirmLabel}
        </button>
      </div>
    </Modal>
  );
}
