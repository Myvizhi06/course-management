import { useEffect } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Courses from './pages/Courses';
import CourseDetails from './pages/CourseDetails';
import Enroll from './pages/Enroll';
import Enrollments from './pages/Enrollments';
import ManageCourses from './pages/ManageCourses';
import AddCourse from './pages/AddCourse';
import EditCourse from './pages/EditCourse';
import NotFound from './pages/NotFound';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => window.scrollTo(0, 0), [pathname]);
  return null;
}

export default function App() {
  return (
    <div className="app-shell">
      <ScrollToTop />
      <Navbar />
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/courses/:id" element={<CourseDetails />} />
          <Route path="/enroll" element={<Enroll />} />
          <Route path="/enrollments" element={<Enrollments />} />
          <Route path="/manage-courses" element={<ManageCourses />} />
          <Route path="/manage-courses/new" element={<AddCourse />} />
          <Route path="/manage-courses/:id/edit" element={<EditCourse />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
