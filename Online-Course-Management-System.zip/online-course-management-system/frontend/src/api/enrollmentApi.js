import api from './axios';

export const getEnrollments = (params = {}, signal) => api.get('/enrollments', { params, signal }).then((r) => r.data);
export const getEnrollment = (id, signal) => api.get(`/enrollments/${id}`, { signal }).then((r) => r.data);
export const createEnrollment = (payload) => api.post('/enrollments', payload).then((r) => r.data);
export const updateEnrollment = (id, payload) => api.put(`/enrollments/${id}`, payload).then((r) => r.data);
export const deleteEnrollment = (id) => api.delete(`/enrollments/${id}`).then((r) => r.data);
