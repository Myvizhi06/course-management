import api from './axios';

export const getStats = (signal) => api.get('/dashboard/stats', { signal }).then((r) => r.data);
