import api from './axios';

// Every backend response looks like { success, message, data }. These helpers return that whole body.
export const getCourses = (params = {}, signal) => api.get('/courses', { params, signal }).then((r) => r.data);
export const getCourse = (id, signal) => api.get(`/courses/${id}`, { signal }).then((r) => r.data);
export const createCourse = (payload) => api.post('/courses', payload).then((r) => r.data);
export const updateCourse = (id, payload) => api.put(`/courses/${id}`, payload).then((r) => r.data);
export const deleteCourse = (id) => api.delete(`/courses/${id}`).then((r) => r.data);
